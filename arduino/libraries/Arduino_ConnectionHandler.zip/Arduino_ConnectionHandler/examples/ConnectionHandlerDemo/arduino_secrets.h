const char SECRET_SSID[] = "NETWORK NAME";
const char SECRET_PASS[] = "NETWORK PASSWORD";

const char SECRET_APN[] 		= "MOBILE PROVIDER APN ADDRESS";
const char SECRET_PIN[] 		= "0000";
const char SECRET_GSM_USER[] 	= "GSM USERNAME";
const char SECRET_GSM_PASS[]	= "GSM PASSWORD";

const char SECRET_APP_EUI[]  = "APP_EUI";
const char SECRET_APP_KEY[]  = "APP_KEY";

const char SECRET_IP[]       = "IP ADDRESS";
const char SECRET_DNS[]      = "DNS ADDRESS";
const char SECRET_GATEWAY[]  = "GATEWAY ADDRESS";
const char SECRET_NETMASK[]  = "NETWORK MASK";
